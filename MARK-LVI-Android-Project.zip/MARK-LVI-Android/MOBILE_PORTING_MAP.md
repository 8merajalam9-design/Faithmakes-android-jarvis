# Desktop-to-Android porting map

The desktop archive is retained under `legacy-desktop/`. It is reference source, not executable Android code.

| Desktop component | Android direction | Current state |
|---|---|---|
| `core/gemini.py`, `core/llm_client.py` | `GeminiClient.kt` | Basic text chat implemented |
| `core/stt.py` | Android SpeechRecognizer intent | Basic voice input implemented |
| `core/tts.py` | Android TextToSpeech | Implemented |
| `actions/open_app.py` | PackageManager + launch intents | Basic app launch implemented |
| `actions/web_search.py` | ACTION_VIEW search intent | Basic search implemented |
| `actions/send_message.py` | Android share/SMS intents | Composer only; user sends |
| `actions/reminder.py` | AlarmManager + BroadcastReceiver | Basic relative reminder |
| `memory/memory_manager.py` | Room/DataStore local database | Not yet ported; chat context is session-only |
| `core/wake_word.py` | Foreground microphone service | Not yet ported |
| `actions/screen_processor.py` | MediaProjection + image pipeline | Not yet ported |
| `actions/computer_control.py` | Android Accessibility APIs | Not yet ported |
| `actions/file_controller.py` | Storage Access Framework | Not yet ported |
| `actions/browser_control.py` | Android browser intents / WebView | Basic external search only |
| `dashboard/server.py` | Android app UI + optional secure API | Not needed for standalone mobile build |
| `ui.py` | Jetpack Compose | Replaced by native mobile UI |
| `plugins/` | Explicitly permissioned Android modules | Not yet ported |

## Why some features need a rewrite

Android apps run in a sandbox. Desktop functions that move the mouse, read arbitrary windows, inspect other apps, change OS settings or access unrestricted files do not have direct Android equivalents. Android requires user-visible permission flows and limits background microphone and screen capture. Any future implementation must use those official APIs rather than attempting to bypass Android protections.
