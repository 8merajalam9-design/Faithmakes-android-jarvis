package com.marklvi.mobile

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    private const val MODEL = "gemini-2.5-flash"

    fun ask(apiKey: String, prompt: String, history: List<Pair<String, String>> = emptyList()): String {
        require(apiKey.isNotBlank()) { "Add your Gemini API key in Settings first." }
        val contents = JSONArray()
        history.takeLast(12).forEach { (role, text) ->
            contents.put(JSONObject().put("role", if (role == "assistant") "model" else "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text))))
        }
        contents.put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", prompt))))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put(
                "text", "You are MARK LVI, a helpful Android voice assistant. Be clear, concise, and honest. " +
                    "Never claim you performed a phone action unless the Android app confirms it. " +
                    "For actions requiring permission or sending a message, ask the user to confirm."
            ))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 1200))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$apiKey")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        return try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) {
                val message = runCatching { JSONObject(response).getJSONObject("error").getString("message") }.getOrDefault(response)
                throw IllegalStateException("Gemini API error (${connection.responseCode}): $message")
            }
            val json = JSONObject(response)
            json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } finally {
            connection.disconnect()
        }
    }
}
