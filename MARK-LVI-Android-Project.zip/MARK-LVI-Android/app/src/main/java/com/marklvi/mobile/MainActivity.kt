package com.marklvi.mobile

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

private val Night = Color(0xFF07111F)
private val Panel = Color(0xFF101F32)
private val Cyan = Color(0xFF58D8F5)
private val Muted = Color(0xFF9BB0C7)

data class ChatLine(val role: String, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MarkLviApp(this) }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }
    fun speak(text: String) { tts?.speak(text.take(2500), TextToSpeech.QUEUE_FLUSH, null, "mark-lvi") }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MarkLviApp(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences("mark_lvi_private", Context.MODE_PRIVATE) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("SYSTEM ONLINE · READY") }
    val messages = remember { mutableStateListOf(ChatLine("assistant", "MARK LVI online. How can I help?")) }
    val scope = rememberCoroutineScope()
    val history = remember { mutableListOf<Pair<String, String>>() }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) status = "MICROPHONE READY" else status = "MICROPHONE PERMISSION DENIED"
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun handleLocalCommand(raw: String): Boolean {
        val command = raw.trim()
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower.startsWith("open ") || lower.startsWith("launch ") -> {
                val target = command.substringAfter(' ').trim()
                val pm = context.packageManager
                val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val apps = pm.queryIntentActivities(launcher, 0)
                val match = apps.firstOrNull { it.loadLabel(pm).toString().contains(target, true) }
                if (match != null) {
                    val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                    if (launch != null) {
                        context.startActivity(launch)
                        messages.add(ChatLine("assistant", "Opening ${match.loadLabel(pm)}."))
                    } else messages.add(ChatLine("assistant", "I couldn't launch that app."))
                } else messages.add(ChatLine("assistant", "I couldn't find an installed app matching '$target'."))
                return true
            }
            lower.startsWith("search ") || lower.startsWith("google ") -> {
                val query = command.substringAfter(' ')
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
                messages.add(ChatLine("assistant", "Opening web search for: $query"))
                return true
            }
            lower.startsWith("whatsapp ") || lower.startsWith("message on whatsapp ") -> {
                val message = command.substringAfter(' ').trim()
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message)
                    setPackage("com.whatsapp")
                }
                try { context.startActivity(send) }
                catch (_: Exception) {
                    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, message), "Share message"))
                }
                messages.add(ChatLine("assistant", "I opened the share composer. Review and send the message yourself."))
                return true
            }
            lower.startsWith("sms ") -> {
                val body = command.substringAfter(' ')
                context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", body))
                messages.add(ChatLine("assistant", "SMS composer opened. Choose a recipient and send when ready."))
                return true
            }
            lower.startsWith("remind me to ") -> {
                val parsed = Regex("remind me to (.+?) in (\\d+) (minute|minutes|hour|hours)", RegexOption.IGNORE_CASE).find(command)
                if (parsed == null) {
                    messages.add(ChatLine("assistant", "Try: Remind me to study in 20 minutes."))
                } else {
                    val task = parsed.groupValues[1]
                    val amount = parsed.groupValues[2].toLong()
                    val unit = parsed.groupValues[3].lowercase()
                    val delay = amount * if (unit.startsWith("hour")) 3600000L else 60000L
                    val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", task)
                    val pi = PendingIntent.getBroadcast(context, reminderIds.incrementAndGet(), intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                    alarm.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pi)
                    messages.add(ChatLine("assistant", "Reminder scheduled: $task"))
                }
                return true
            }
        }
        return false
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Cyan, onPrimary = Night,
        onBackground = Color.White, onSurface = Color.White, secondary = Muted
    )) {
        Scaffold(containerColor = Night, topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("MARK LVI", fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("PERSONAL AI SYSTEM", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Cyan) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Night)
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(8.dp).background(Cyan, CircleShape))
                    Text(status, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.weight(1f))
                    Text("MOBILE · STANDALONE", color = Cyan, fontSize = 9.sp)
                }
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth().height(154.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(142.dp).background(Brush.radialGradient(listOf(Color(0xFF164A69), Color(0xFF0A1B2D), Night)), CircleShape))
                    Box(Modifier.size(108.dp).background(Color(0xFF102A40), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Memory, contentDescription = "MARK LVI core", tint = Cyan, modifier = Modifier.size(58.dp))
                    }
                    Box(Modifier.size(126.dp).background(Color.Transparent, CircleShape))
                }
                Text("HOW CAN I ASSIST?", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(messages) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.role == "user") Arrangement.End else Arrangement.Start) {
                            Column(Modifier.widthIn(max = 310.dp).background(
                                if (line.role == "user") Color(0xFF123B50) else Panel,
                                RoundedCornerShape(16.dp)
                            ).padding(12.dp)) {
                                Text(if (line.role == "user") "YOU" else "MARK LVI", color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(line.text, color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                    if (busy) item { Text("MARK LVI IS THINKING…", color = Cyan, fontSize = 11.sp) }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask MARK LVI…", color = Muted) },
                        shape = RoundedCornerShape(18.dp), maxLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF294158),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                            micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MARK LVI")
                            }
                            if (SpeechRecognizer.isRecognitionAvailable(context)) speechLauncher.launch(intent)
                            else status = "VOICE RECOGNITION UNAVAILABLE"
                        }
                    }) { Icon(Icons.Default.Mic, "Voice input", tint = Cyan) }
                    IconButton(enabled = !busy && input.isNotBlank(), onClick = {
                        val prompt = input.trim()
                        input = ""
                        messages.add(ChatLine("user", prompt))
                        if (handleLocalCommand(prompt)) return@IconButton
                        busy = true
                        scope.launch {
                            try {
                                val response = withContext(Dispatchers.IO) {
                                    GeminiClient.ask(apiKey, prompt, history.toList())
                                }
                                messages.add(ChatLine("assistant", response))
                                history.add("user" to prompt); history.add("assistant" to response)
                                activity.speak(response)
                                status = "RESPONSE RECEIVED"
                            } catch (e: Exception) {
                                messages.add(ChatLine("assistant", e.message ?: "Something went wrong."))
                                status = "CHECK API KEY / INTERNET"
                            } finally { busy = false }
                        }
                    }) { Icon(Icons.Default.Send, "Send", tint = if (input.isNotBlank()) Cyan else Muted) }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    QuickAction("OPEN APP", Icons.Default.Apps) { input = "Open " }
                    QuickAction("SEARCH", Icons.Default.Search) { input = "Search " }
                    QuickAction("REMINDER", Icons.Default.Alarm) { input = "Remind me to " }
                    QuickAction("SETTINGS", Icons.Default.Tune) { showSettings = true }
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("MARK LVI SETTINGS") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Gemini API key", color = Muted)
                        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, placeholder = { Text("Paste your API key") }, singleLine = true)
                        Text("The key is saved in this app's private preferences. API requests use your internet connection and may incur provider charges.", fontSize = 12.sp, color = Muted)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("gemini_key", apiKey.trim()).apply()
                        showSettings = false
                    }) { Text("SAVE") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("CANCEL") } }
            )
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 4.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(19.dp))
            Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 0.5.sp)
        }
    }
}

private val reminderIds = AtomicInteger(1000)
