# MARK LVI Android

A native Android rebuild of the uploaded MARK LVI desktop assistant, designed to run on a phone without requiring a PC.

## What works in this mobile starter

- Modern dark JARVIS-style Android interface (Jetpack Compose).
- Gemini-powered chat using your own API key.
- Android speech recognition through the device speech service.
- Spoken responses using Android TextToSpeech.
- Open installed apps by saying/typing `open YouTube`, `launch Settings`, etc.
- Web search using `search ...`.
- WhatsApp share composer using `whatsapp ...` (you review and press Send).
- SMS composer using `sms ...` (you choose recipient and press Send).
- Local reminders such as `remind me to study in 20 minutes`.
- Conversation context for the current app session.
- GitHub Actions workflow to build a debug APK.

## Important: what this is and is not

This is a **native Android foundation**, not a byte-for-byte port of the desktop program. The uploaded Python project uses PyQt6, desktop mouse/keyboard automation, desktop file APIs, Playwright and OS-specific modules. Those cannot run unchanged inside Android.

The original desktop source is preserved in `legacy-desktop/` for reference. Android equivalents must be implemented module by module.

Not yet implemented in this starter:
- Always-listening wake-word service.
- Continuous background conversations.
- Android Accessibility Service automation.
- Live screen capture/vision sharing.
- Full file manager and arbitrary system-setting control.
- Desktop browser/computer-control features.
- Importing the desktop Python plugin system.

These require separate Android-native implementations, user-granted permissions, and careful testing. This app does not silently read your screen or send messages.

## Requirements

- Android Studio Ladybug or newer.
- JDK 17.
- Android SDK Platform 35.
- Internet connection for Gemini.
- A Gemini API key. Create/manage it through Google's official AI developer tools. Keep it private.

Minimum Android version: Android 8.0 (API 26). Target SDK: 35.

## Build on Android phone using GitHub

1. Extract this ZIP.
2. Create a new GitHub repository, for example `MARK-LVI-Android`.
3. Upload the **contents** of this folder (not the outer folder) to the repository.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and wait for the workflow to finish.
6. Open the completed workflow run.
7. Under **Artifacts**, download `MARK-LVI-debug-apk`.
8. Extract the downloaded artifact and install `app-debug.apk`.

If GitHub asks to enable Actions, enable them for the repository. The first build can take several minutes.

## Build in Android Studio

Open this folder as a project, allow Gradle sync, then run:

```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## First launch

1. Open MARK LVI.
2. Tap Settings.
3. Add your Gemini API key and save.
4. Allow microphone permission when using voice input.
5. Try `What can you do?`, `open YouTube`, `search space news`, or `remind me to take a break in 30 minutes`.

## Privacy and safety

- API key is stored in app-private SharedPreferences; it is not hardcoded in the source.
- Do not upload your API key to GitHub or share screenshots containing it.
- Chat prompts are sent to Google's Gemini API when you use AI chat.
- Android speech recognition may use the device's configured recognition service.
- WhatsApp and SMS actions open a composer; the user reviews and sends.
- App launching only opens an installed app; it does not bypass app permissions.
- Reminder alarms may be delayed by Android battery policies.
- No hidden screen recording, message reading, or background surveillance is included.

## Original project relationship

`legacy-desktop/` contains the supplied desktop source as a reference. Its Python modules are not bundled into the APK. The mobile app reimplements selected features using Android APIs and a Gemini HTTP client.
